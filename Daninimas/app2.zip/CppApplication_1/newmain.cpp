/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: victor
 *
 * Created on 25 de noviembre de 2017, 22:53
 */

#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <SFML/Window/Event.hpp>

using namespace std;

/*
 * 
 */
#define kVel 8
#define kWinX 1300
#define kWinY 680

int main(int argc, char** argv)
{    
    
    //--------------DEFINITIONS----------------------------
    
    int mouseDelta = 0;
    int mouseDeltaAux = 0;
    
    
    //------------------------------------------------------
    sf::RenderWindow window(sf::VideoMode(kWinX, kWinY), "hibuddyAPP");
    //------------------------------------------------------
    
    //-------------ZOOM TEXTURES-------------------------
    sf::Texture tZoom1;
    if (!tZoom1.loadFromFile("assets/zoom1.png"))
    {
        // error...
    }
    
    sf::Texture tZoom2;
    if (!tZoom2.loadFromFile("assets/zoom2.png"))
    {
        // error...
    }
    
    sf::Texture tZoom3;
    if (!tZoom3.loadFromFile("assets/zoom3.png"))
    {
        // error...
    }
    
    sf::Texture tZoom4;
    if (!tZoom4.loadFromFile("assets/zoom4.png"))
    {
        // error...
    }
    
    sf::Texture tZoom5;
    if (!tZoom5.loadFromFile("assets/zoom5.png"))
    {
        // error...
    }
    
    sf::Texture zoomTexture[5] = {tZoom1, tZoom2,tZoom3,tZoom4,tZoom5 };
    
    
    //--------------SPRITE ZOOM-----------------------------
    
    sf::Sprite sMap;
    sMap.setTexture(tZoom1);
    sMap.setOrigin(sMap.getTexture()->getSize().x/2, sMap.getTexture()->getSize().y/2);
    sMap.setPosition(kWinX/2 + 50, kWinY/2);
    
    //------------------------------------------------------
    
    
    sf::Texture tMira;
    if (!tMira.loadFromFile("assets/mira.png"))
    {
        // error...
    }
    sf::Sprite sMira;
    tMira.setSmooth(true);
    sMira.setTexture(tMira);
    sMira.setOrigin(9/2,9/2);
    sMira.setPosition(kWinX/2, kWinY/2);

    sf::Texture tMarco;
    if (!tMarco.loadFromFile("assets/marco.png"))
    {
        // error...
    }
    sf::Sprite sMarco;
    sMarco.setTexture(tMarco);
    sMarco.setOrigin(sMarco.getTexture()->getSize().x/2, sMarco.getTexture()->getSize().y/2 );
    sMarco.setPosition(kWinX/2, kWinY/2);
    
    sf::Texture tFondo;
    if (!tFondo.loadFromFile("assets/fondo.png"))
    {
        // error...
    }
    sf::Sprite sFondo;
    sFondo.setTexture(tFondo);
    sFondo.setOrigin(sFondo.getTexture()->getSize().x/2, sFondo.getTexture()->getSize().y/2 );
    sFondo.setPosition(kWinX/2, kWinY/2);
    
  
    
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::MouseWheelMoved)
            {
                mouseDeltaAux += event.mouseWheel.delta;
                if(( mouseDeltaAux < 0 && mouseDelta == 0 ) || ( mouseDeltaAux > 0 && mouseDelta == 4 )){
                         
                } else{
                    mouseDelta += mouseDeltaAux;
                    
                    //if(mouseDeltaAux<){
                        
                    //}
                    
                }
                mouseDeltaAux= 0;
                //sMap.setOrigin(sf::Mouse::getPosition().x,sf::Mouse::getPosition().y);
                sMap.setTexture(zoomTexture[mouseDelta]);
                
                         
            }
            
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
            {
                // move left...
                sMap.move(kVel,0);
                sMap.setOrigin((sMap.getOrigin().x)-kVel, sMap.getOrigin().y);
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
            {
                // move right...
                sMap.move(-kVel,0);
                sMap.setOrigin((sMap.getOrigin().x)+kVel, sMap.getOrigin().y);
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
            {
                // move up...
                sMap.move(0,kVel);
                sMap.setOrigin((sMap.getOrigin().x), (sMap.getOrigin().y)-kVel);
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
            {
                // move left...
                sMap.move(0,-kVel);
                sMap.setOrigin((sMap.getOrigin().x), (sMap.getOrigin().y)+kVel);
            }
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Add)){
                //zoom in
                sMap.scale(1.08f, 1.08f);
            }
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Subtract)){
                //zoom out
                sMap.scale(0.92f, 0.92f);
            }
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();
        
        window.draw(sMap);
        window.draw(sFondo);
        window.draw(sMarco);
        window.draw(sMira);
        
        window.display();
    }

    return 0;
}

